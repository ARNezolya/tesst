
# Hotel Bot (Embeddable Booking Chat)

Готовый виджет-бот для сайтов отелей: бронирование через кнопки + возможность написать вопрос (ответы на основе инфо об отеле через OpenAI).  
Мультиязычный, пишет заявки в БД и отправляет письмо отелю. Готов к интеграциям.

## Быстрый старт (локально)

```bash
cd hotel-bot
npm install
cp .env.example .env          # заполните SMTP и OPENAI при необходимости
npx prisma migrate dev --name init
npm run dev
```

Откройте `http://localhost:8787` для локального предпросмотра.

## Встраивание на сайт отеля

Вставьте на страницу сайта (замените `data-server` на ваш домен/API):

```html
<div data-hotel-bot id="hotel-bot"
     data-hotel-id="demo-hotel"
     data-lang="auto"
     data-server="https://YOUR_DOMAIN"
     data-theme="light"></div>
<script src="https://YOUR_DOMAIN/public/widget.js" defer></script>
```

- `data-hotel-id` — ID отеля (см. `data/hotels.json`).
- `data-lang` — `auto` или явный язык (`en`, `ru`, ...).
- `data-server` — базовый URL вашего сервера (где крутится `server.js`).
- `data-theme` — `light` | `dark` (минимальное влияние, стили адаптивны).

## Что уже работает

- ✨ Красивый компактный виджет (iframe, чтобы не ломать стили сайта).
- 🧭 Основной поток бронирования через кнопки: даты → гости → тип номера → контакты → заявка.
- 💾 Сохранение брони в БД (Prisma + SQLite по умолчанию).
- ✉️ Авто-уведомление отелю на email (SMTP, `FALLBACK_HOTEL_EMAIL` или email в `hotels.json`).
- 💬 Поле чата: свободный вопрос → ответ ИИ на основе `hotel_info` конкретного отеля.
- 🌐 Мультиязычность (en/ru из коробки), авто-детект, лёгкое расширение.
- 🔒 CORS (разрешения через `ALLOWED_ORIGINS`).

## Настройка

### ENV
См. `.env.example`. Главное:
- `ALLOWED_ORIGINS` — список разрешённых доменов (по умолчанию `*`).
- `FALLBACK_HOTEL_EMAIL` — почта, куда отправлять заявки.
- SMTP_* — настройки вашей почты (через `nodemailer`).
- `OPENAI_API_KEY` — включит ответы ИИ.
- `OPENAI_MODEL` — модель, по умолчанию `gpt-4o-mini`.

### Отели и номера
Файл `data/hotels.json`:
- `languages` — поддерживаемые локали.
- `rooms` — список типов номеров (id / имя / цена).
- `hotel_info` — справочная инфа для ИИ (на нескольких языках).

### БД
Prisma схема в `prisma/schema.prisma`. По умолчанию SQLite.  
Хотите PostgreSQL? Замените `provider` и `DATABASE_URL` в `.env`, затем миграции.

## API

- `GET /api/rooms?hotelId=...&locale=...` — список номеров.
- `POST /api/bookings` — создать бронь:
  ```json
  {
    "hotelId": "demo-hotel",
    "locale": "en",
    "booking": {
      "checkIn": "2025-10-12",
      "checkOut": "2025-10-15",
      "adults": 2,
      "children": 0,
      "roomType": "std",
      "extras": { "breakfast": true },
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "+123",
      "comments": "Late arrival"
    }
  }
  ```
- `POST /api/chat` — вопрос к ИИ:
  ```json
  { "hotelId": "demo-hotel", "locale":"en", "message": "Do you allow pets?" }
  ```

## Деплой и раздача виджета

- Запустите `server.js` (PM2/Docker/Render/Fly/Your VPS).
- Отдавайте `/public` статику: `https://YOUR_DOMAIN/public/widget.js` и `iframe.html` + ассеты.
- Разрешите домены отелей в `ALLOWED_ORIGINS`.

## Интеграции с PMS/Channel Manager

Сейчас — письма + запись в БД. Для последующей интеграции:
- Добавьте webhooks: при создании брони отправляйте POST на URL отеля.
- Реализуйте маппинг `roomType -> PMS room code`.
- Добавьте `status`/`confirmed` подпоток после ответа PMS.

## Кастомизация внешнего вида

Правьте `public/styles.css`. При необходимости можно сделать цветовую тему через CSS-переменные.

## Лицензия
MIT
