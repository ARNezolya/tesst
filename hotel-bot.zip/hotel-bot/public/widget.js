
(() => {
  function getScriptBase() {
    const current = document.currentScript || (function() {
      const scripts = document.getElementsByTagName('script');
      return scripts[scripts.length - 1];
    })();
    const src = current && current.src ? current.src : '';
    return src.replace(/\/[^\/]*$/, '');
  }

  function ready(fn) {
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  ready(() => {
    const containers = Array.from(document.querySelectorAll('[data-hotel-bot], #hotel-bot'));
    const base = getScriptBase();
    containers.forEach(el => {
      const hotelId = el.getAttribute('data-hotel-id') || 'demo-hotel';
      const lang = el.getAttribute('data-lang') || 'auto';
      const theme = el.getAttribute('data-theme') || 'light'; // light|dark
      const server = el.getAttribute('data-server') || (window.HOTEL_BOT_SERVER || '');
      const title = el.getAttribute('data-title') || '';
      const iframe = document.createElement('iframe');
      iframe.allow = 'clipboard-write; clipboard-read;';
      iframe.style.border = '0';
      iframe.style.width = '360px';
      iframe.style.height = '560px';
      iframe.style.maxWidth = '100%';
      iframe.style.boxShadow = '0 10px 30px rgba(0,0,0,.15)';
      iframe.style.borderRadius = '16px';
      iframe.loading = 'lazy';

      const q = new URLSearchParams({
        hotelId, lang, theme, server, title
      }).toString();
      iframe.src = base + '/iframe.html?' + q;
      el.appendChild(iframe);
    });
  });
})();
