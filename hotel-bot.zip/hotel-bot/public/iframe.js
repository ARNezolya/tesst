
import { initI18n } from './i18n.js';

const params = new URLSearchParams(location.search);
const HOTEL_ID = params.get('hotelId') || 'demo-hotel';
const PREFERRED_LANG = params.get('lang') || 'auto';
const THEME = params.get('theme') || 'light';
const SERVER = params.get('server') || '';
const TITLE_OVERRIDE = params.get('title') || '';

const state = {
  locale: 'en',
  t: (k) => k,
  booking: {
    checkIn: '',
    checkOut: '',
    adults: 2,
    children: 0,
    roomType: '',
    extras: {},
    name: '',
    email: '',
    phone: '',
    comments: ''
  },
  rooms: []
};

const els = {
  hello: document.getElementById('hello'),
  quick: document.getElementById('quick'),
  flow: document.getElementById('flow'),
  title: document.getElementById('bot-title'),
  sub: document.getElementById('bot-sub'),
  powered: document.getElementById('powered'),
  btnBook: document.getElementById('btn-book'),
  btnAsk: document.getElementById('btn-ask'),
  chatForm: document.getElementById('chat-form'),
  chatInput: document.getElementById('chat-input'),
  messages: document.getElementById('messages')
};

function addMsg(role, text) {
  const div = document.createElement('div');
  div.className = role === 'user' ? 'msg msg--user' : 'msg msg--bot';
  const bubble = document.createElement('div');
  bubble.className = 'msg__bubble';
  bubble.textContent = text;
  div.appendChild(bubble);
  els.messages.appendChild(div);
  els.messages.scrollTop = els.messages.scrollHeight;
}

function clearFlow() {
  els.flow.innerHTML = '';
}

async function fetchJSON(url, opts={}) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return await r.json();
}

async function setup() {
  const lang = PREFERRED_LANG === 'auto' ? (navigator.language || 'en').slice(0,2) : PREFERRED_LANG;
  const { t, locale } = await initI18n(lang);
  state.t = t; state.locale = locale;

  els.title.textContent = TITLE_OVERRIDE || t('title');
  els.sub.textContent = HOTEL_ID;
  els.powered.textContent = t('powered');
  els.hello.textContent = t('greeting');
  els.btnBook.textContent = t('btn_book');
  els.btnAsk.textContent = t('btn_ask');
  els.chatInput.placeholder = t('ask_placeholder');

  els.btnBook.addEventListener('click', startBooking);
  els.btnAsk.addEventListener('click', () => {
    els.chatInput.focus();
  });

  // Load rooms
  try {
    const data = await fetchJSON(`${SERVER}/api/rooms?hotelId=${encodeURIComponent(HOTEL_ID)}&locale=${locale}`);
    state.rooms = data.rooms || [];
  } catch (e) {
    console.warn('Failed to load rooms', e);
  }

  // Handle chat
  els.chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = els.chatInput.value.trim();
    if (!text) return;
    addMsg('user', text);
    els.chatInput.value = '';
    try {
      const res = await fetchJSON(`${SERVER}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hotelId: HOTEL_ID, locale: state.locale, message: text })
      });
      addMsg('bot', res.reply || '—');
    } catch (err) {
      addMsg('bot', state.t('error'));
    }
  });
}

function startBooking() {
  clearFlow();
  stepDates();
}

function stepDates() {
  clearFlow();
  const wrap = document.createElement('div');
  wrap.className = 'flow';

  const title = document.createElement('div');
  title.textContent = state.t('flow_dates');
  wrap.appendChild(title);

  const row1 = document.createElement('div');
  row1.className = 'row';
  const f1 = document.createElement('div'); f1.className='field';
  const l1 = document.createElement('label'); l1.textContent = state.t('checkin');
  const i1 = document.createElement('input'); i1.type='date'; i1.value=state.booking.checkIn; i1.oninput = e => state.booking.checkIn = e.target.value;
  f1.append(l1, i1);
  const f2 = document.createElement('div'); f2.className='field';
  const l2 = document.createElement('label'); l2.textContent = state.t('checkout');
  const i2 = document.createElement('input'); i2.type='date'; i2.value=state.booking.checkOut; i2.oninput = e => state.booking.checkOut = e.target.value;
  f2.append(l2, i2);
  row1.append(f1, f2);

  const row2 = document.createElement('div');
  row2.className = 'row';
  const f3 = document.createElement('div'); f3.className='field';
  const l3 = document.createElement('label'); l3.textContent = state.t('adults');
  const i3 = document.createElement('input'); i3.type='number'; i3.min='1'; i3.value=state.booking.adults; i3.oninput=e=>state.booking.adults=+e.target.value;
  f3.append(l3, i3);
  const f4 = document.createElement('div'); f4.className='field';
  const l4 = document.createElement('label'); l4.textContent = state.t('children');
  const i4 = document.createElement('input'); i4.type='number'; i4.min='0'; i4.value=state.booking.children; i4.oninput=e=>state.booking.children=+e.target.value;
  f4.append(l4, i4);
  row2.append(f3, f4);

  const actions = document.createElement('div'); actions.className='row';
  const next = document.createElement('button'); next.className='btn'; next.textContent=state.t('next'); next.onclick = stepRooms;
  actions.append(next);

  wrap.append(row1, row2, actions);
  els.flow.appendChild(wrap);
}

function stepRooms() {
  clearFlow();
  const wrap = document.createElement('div');
  wrap.className = 'flow';
  const title = document.createElement('div');
  title.textContent = state.t('choose_room');
  wrap.appendChild(title);

  const list = document.createElement('div');
  list.className = 'select-list';
  state.rooms.forEach(r => {
    const b = document.createElement('button');
    b.className = 'btn btn--ghost';
    b.textContent = `${r.name} • ${r.price}€`;
    b.onclick = () => { state.booking.roomType = r.id; stepContact(); };
    list.appendChild(b);
  });
  wrap.appendChild(list);

  const back = document.createElement('button'); back.className = 'btn btn--ghost'; back.textContent = state.t('back'); back.onclick = stepDates;
  wrap.appendChild(back);
  els.flow.appendChild(wrap);
}

function stepContact() {
  clearFlow();
  const wrap = document.createElement('div');
  wrap.className = 'flow';

  const f1 = mkField('name', 'text', state.booking.name, v => state.booking.name = v);
  const f2 = mkField('email', 'email', state.booking.email, v => state.booking.email = v);
  const f3 = mkField('phone', 'tel', state.booking.phone, v => state.booking.phone = v);
  const f4 = mkField('comments', 'text', state.booking.comments, v => state.booking.comments = v, true);

  const summary = document.createElement('div'); summary.className='summary';
  summary.textContent = state.t('summary');
  wrap.append(f1, f2, f3, f4, summary);

  const actions = document.createElement('div'); actions.className = 'row';
  const confirm = document.createElement('button'); confirm.className='btn'; confirm.textContent = state.t('confirm');
  confirm.onclick = submitBooking;
  const back = document.createElement('button'); back.className='btn btn--ghost'; back.textContent = state.t('back'); back.onclick = stepRooms;
  actions.append(confirm, back);
  wrap.append(actions);

  els.flow.appendChild(wrap);
}

function mkField(key, type, value, oninput, multiline=false) {
  const d = document.createElement('div'); d.className='field';
  const l = document.createElement('label'); l.textContent = state.t(key);
  let input;
  if (multiline) {
    input = document.createElement('textarea');
    input.rows = 3;
  } else {
    input = document.createElement('input');
    input.type = type;
  }
  input.value = value || '';
  input.oninput = e => oninput(e.target.value);
  d.append(l, input);
  return d;
}

async function submitBooking() {
  const msg = document.createElement('div');
  msg.className = 'msg msg--bot';
  const b = document.createElement('div'); b.className='msg__bubble'; b.textContent = state.t('sending');
  msg.appendChild(b); els.messages.appendChild(msg); els.messages.scrollTop = els.messages.scrollHeight;

  try {
    const res = await fetchJSON(`${SERVER}/api/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hotelId: HOTEL_ID,
        locale: state.locale,
        booking: state.booking
      })
    });
    b.textContent = state.t('done');
    clearFlow();
  } catch (e) {
    b.textContent = state.t('error');
    b.classList.add('error');
  }
}

setup();
