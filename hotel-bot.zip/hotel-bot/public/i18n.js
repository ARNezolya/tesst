
export async function initI18n(pref) {
  const tryLangs = Array.from(new Set([pref, (navigator.language||'en').slice(0,2), 'en'])).filter(Boolean);
  for (const lang of tryLangs) {
    try {
      const res = await fetch(`./i18n/${lang}.json`);
      if (res.ok) {
        const dict = await res.json();
        const t = (k) => dict[k] || k;
        return { t, locale: lang };
      }
    } catch (e) {}
  }
  return { t: (k)=>k, locale: 'en' };
}
