
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import nodemailer from 'nodemailer';
import { PrismaClient } from '@prisma/client';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import OpenAI from 'openai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const prisma = new PrismaClient();

const PORT = process.env.PORT || 8787;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '*')
  .split(',')
  .map(s => s.trim());
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}/public`;

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const HOTEL_QA_SYSTEM_PROMPT = process.env.HOTEL_QA_SYSTEM_PROMPT || 
  'You are a helpful hotel assistant. Answer only using the provided hotel_info.';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: String(process.env.SMTP_SECURE || 'false') === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

// CORS
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes('*') || ALLOWED_ORIGINS.includes(origin)) {
      cb(null, true);
    } else {
      cb(new Error('Not allowed by CORS: ' + origin));
    }
  }
}));
app.use(bodyParser.json({ limit: '1mb' }));

// Static files for the widget
app.use('/public', express.static(path.join(__dirname, 'public')));

// Hotels registry
const hotelsPath = path.join(__dirname, 'data', 'hotels.json');
function loadHotels() {
  const raw = fs.readFileSync(hotelsPath, 'utf-8');
  return JSON.parse(raw);
}

// Health
app.get('/health', (_, res) => res.json({ ok: true }));

// Rooms endpoint (demo)
app.get('/api/rooms', async (req, res) => {
  const hotelId = String(req.query.hotelId || '');
  const locale = String(req.query.locale || 'en');
  const all = loadHotels();
  const hotel = all[hotelId] || all['demo-hotel'];
  const rooms = (hotel.rooms || []).map(r => ({
    id: r.id,
    name: (r.name && (r.name[locale] || r.name['en'])) || r.id,
    price: r.price
  }));
  res.json({ rooms });
});

// Bookings
app.post('/api/bookings', async (req, res) => {
  try {
    const { hotelId, locale, booking } = req.body;
    if (!hotelId || !booking) {
      return res.status(400).json({ error: 'Bad request' });
    }
    const saved = await prisma.booking.create({
      data: {
        hotelId,
        locale: locale || 'en',
        checkIn: new Date(booking.checkIn),
        checkOut: new Date(booking.checkOut),
        adults: Number(booking.adults || 1),
        children: Number(booking.children || 0),
        roomType: String(booking.roomType || ''),
        extras: booking.extras ? JSON.stringify(booking.extras) : null,
        guestName: String(booking.name || ''),
        email: String(booking.email || ''),
        phone: booking.phone ? String(booking.phone) : null,
        comments: booking.comments ? String(booking.comments) : null
      }
    });

    // Notify hotel by email
    const all = loadHotels();
    const hotel = all[hotelId] || all['demo-hotel'];
    const to = hotel.email || process.env.FALLBACK_HOTEL_EMAIL;
    if (to) {
      const subject = `[Booking] ${hotel.name || hotelId} — ${saved.guestName} (${saved.checkIn.toISOString().slice(0,10)} → ${saved.checkOut.toISOString().slice(0,10)})`;
      const text = `New booking:
Hotel: ${hotel.name || hotelId}
Guest: ${saved.guestName}
Email: ${saved.email}
Phone: ${saved.phone || '-'}
Dates: ${saved.checkIn.toISOString().slice(0,10)} → ${saved.checkOut.toISOString().slice(0,10)}
Guests: ${saved.adults} adults, ${saved.children} children
Room: ${saved.roomType}
Comments: ${saved.comments || '-'}
Locale: ${saved.locale}
Created: ${saved.createdAt.toISOString()}`;

      await transporter.sendMail({
        from: process.env.FROM_EMAIL || 'bot@example.com',
        to,
        subject,
        text
      });
    }

    res.json({ ok: true, id: saved.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Chat (Q&A with hotel's knowledge via OpenAI)
app.post('/api/chat', async (req, res) => {
  try {
    const { hotelId, locale, message } = req.body;
    const all = loadHotels();
    const hotel = all[hotelId] || all['demo-hotel'];
    const hotel_info = (hotel.hotel_info && (hotel.hotel_info[locale] || hotel.hotel_info['en'])) || '';

    // Save user message
    await prisma.chatLog.create({ data: { hotelId, locale: locale || 'en', role: 'user', content: message } });

    let reply = 'AI is disabled.';
    if (OPENAI_API_KEY) {
      const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
      const completion = await openai.chat.completions.create({
        model: OPENAI_MODEL,
        temperature: 0.2,
        messages: [
          { role: 'system', content: HOTEL_QA_SYSTEM_PROMPT },
          { role: 'system', content: `hotel_info: ${hotel_info}` },
          { role: 'user', content: message }
        ]
      });
      reply = completion.choices?.[0]?.message?.content?.trim() || '—';
    } else {
      reply = 'Set OPENAI_API_KEY on the server to enable hotel Q&A.';
    }

    await prisma.chatLog.create({ data: { hotelId, locale: locale || 'en', role: 'assistant', content: reply } });
    res.json({ reply });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Helper to serve the embed snippet for quick testing
app.get('/', (req, res) => {
  const snippet = `<div data-hotel-bot id="hotel-bot" data-hotel-id="demo-hotel" data-lang="auto" data-server="http://localhost:${PORT}"></div>
<script src="http://localhost:${PORT}/public/widget.js" defer></script>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(`<h1>Hotel Bot</h1><p>Embed preview below:</p>${snippet}`);
});

app.listen(PORT, () => {
  console.log('Hotel Bot API on http://localhost:' + PORT);
  console.log('Widget files served from ' + PUBLIC_BASE_URL);
});
